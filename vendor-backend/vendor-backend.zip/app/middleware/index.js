const authJwt = require('./auth-jwt');
const verifySignUp = require('./verify-signup');
module.exports = {
  authJwt,
  verifySignUp
};
