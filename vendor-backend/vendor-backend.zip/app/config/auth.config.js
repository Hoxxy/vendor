module.exports = {
  secret: "vendor-secret-key"
};
